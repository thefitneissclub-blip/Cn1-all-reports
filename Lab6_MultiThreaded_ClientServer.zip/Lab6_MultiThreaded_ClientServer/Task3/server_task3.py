import socket
import threading

HOST = "127.0.0.1"
PORT = 5050
clients = {}
clients_lock = threading.Lock()
running = True

def handle_client(conn, addr):
    cid = f"{addr[0]}:{addr[1]}"
    with clients_lock:
        clients[cid] = conn
    print(f"[CONNECTED] {cid}")

    try:
        while True:
            msg = conn.recv(1024).decode()
            if not msg:
                break
            conn.send(f"Echo: {msg}".encode())
    except:
        pass
    finally:
        with clients_lock:
            if cid in clients:
                del clients[cid]
        conn.close()
        print(f"[DISCONNECTED] {cid}")

def accept_clients(server):
    global running
    while running:
        try:
            server.settimeout(1.0)
            conn, addr = server.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
        except socket.timeout:
            continue
        except OSError:
            break

def main():
    global running
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[LISTENING] Server on {HOST}:{PORT}")

    threading.Thread(target=accept_clients, args=(server,), daemon=True).start()

    while True:
        cmd = input("Server> ").lower()
        if cmd == "list":
            with clients_lock:
                if clients:
                    print(f"[ACTIVE CLIENTS] {len(clients)}")
                    for cid in clients:
                        print(" -", cid)
                else:
                    print("[INFO] No active clients.")
        elif cmd == "exit":
            print("[CLOSING] Server shutting down...")
            running = False
            server.close()
            break

if __name__ == "__main__":
    main()
