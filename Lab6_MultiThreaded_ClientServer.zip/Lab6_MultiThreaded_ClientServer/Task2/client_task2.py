import socket

HOST = "127.0.0.1"
PORT = 5050

try:
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))
    print("[CONNECTED] Connected to server.")
    while True:
        data = client.recv(1024)
        if not data:
            break
        print("Server:", data.decode().strip())
        msg = input("You: ")
        if msg.lower() == "quit":
            break
        client.send(msg.encode())
except Exception as e:
    print("[ERROR] Could not connect to server.", e)
finally:
    client.close()
    print("[CLOSED] Client terminated.")
