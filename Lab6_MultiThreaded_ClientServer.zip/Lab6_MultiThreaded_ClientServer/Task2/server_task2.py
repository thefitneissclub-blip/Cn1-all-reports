import socket
import threading

HOST = "127.0.0.1"
PORT = 5050
running = True

def handle_client(conn, addr):
    print(f"[CONNECTED] {addr}")
    conn.send(b"You are connected to the echo server.\n")
    try:
        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            conn.send(f"Echo: {data}".encode())
    except:
        pass
    finally:
        conn.close()
        print(f"[DISCONNECTED] {addr}")

def accept_clients(sock):
    global running
    while running:
        try:
            sock.settimeout(1.0)
            conn, addr = sock.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
        except socket.timeout:
            continue
        except OSError:
            break

def main():
    global running
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[LISTENING] Server on {HOST}:{PORT}")

    threading.Thread(target=accept_clients, args=(server,), daemon=True).start()

    while True:
        cmd = input("Server> ").lower()
        if cmd == "exit":
            print("[CLOSING] Shutting down server...")
            running = False
            server.close()
            break

if __name__ == "__main__":
    main()
