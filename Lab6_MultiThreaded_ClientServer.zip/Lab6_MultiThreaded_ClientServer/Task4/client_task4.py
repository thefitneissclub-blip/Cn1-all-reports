import socket
import threading

HOST = "127.0.0.1"
PORT = 5050

def receive(sock):
    while True:
        try:
            data = sock.recv(1024)
            if not data:
                break
            print(data.decode(), end="")
        except:
            break

def main():
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((HOST, PORT))
        print("[CONNECTED] Joined the group chat.")
    except:
        print("[ERROR] Could not connect to chat server.")
        return

    threading.Thread(target=receive, args=(client,), daemon=True).start()

    while True:
        msg = input()
        if msg.lower() == "/exit":
            client.send(msg.encode())
            break
        client.send(msg.encode())

    client.close()
    print("[CLOSED] Connection ended.")

if __name__ == "__main__":
    main()
