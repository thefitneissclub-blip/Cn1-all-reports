import socket
import threading

HOST = "127.0.0.1"
PORT = 5050
clients = {}
lock = threading.Lock()
running = True

def broadcast(message, sender=None):
    with lock:
        for cid, conn in list(clients.items()):
            if cid != sender:
                try:
                    conn.sendall(message.encode())
                except:
                    conn.close()
                    del clients[cid]

def handle_client(conn, addr):
    cid = f"{addr[0]}:{addr[1]}"
    with lock:
        clients[cid] = conn
    print(f"[CONNECTED] {cid}")
    conn.send(b"Welcome to the chatroom!\nUse /exit to leave.\n")
    broadcast(f"[SERVER] {cid} joined the chat.\n", sender=cid)

    try:
        while True:
            msg = conn.recv(1024).decode().strip()
            if not msg:
                break
            if msg.lower() == "/exit":
                conn.send(b"Goodbye!\n")
                break
            print(f"[{cid}] {msg}")
            broadcast(f"[{cid}] {msg}\n", sender=cid)
    finally:
        with lock:
            if cid in clients:
                del clients[cid]
        conn.close()
        broadcast(f"[SERVER] {cid} left the chat.\n")
        print(f"[DISCONNECTED] {cid}")

def accept_clients(server):
    global running
    while running:
        try:
            server.settimeout(1.0)
            conn, addr = server.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
        except socket.timeout:
            continue
        except OSError:
            break

def main():
    global running
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[LISTENING] Chat Server on {HOST}:{PORT}")

    threading.Thread(target=accept_clients, args=(server,), daemon=True).start()

    while True:
        cmd = input("Server> ").lower()
        if cmd == "list":
            with lock:
                print(f"[ACTIVE USERS] {list(clients.keys())}")
        elif cmd == "exit":
            print("[SHUTDOWN] Closing chat server...")
            running = False
            server.close()
            break

if __name__ == "__main__":
    main()
