import socket
import threading
import json
import os

HOST = "127.0.0.1"
PORT = 5050
DB_FILE = "users.json"

# Ensure database file exists
if not os.path.exists(DB_FILE):
    with open(DB_FILE, "w") as f:
        json.dump({}, f)

def read_users():
    with open(DB_FILE, "r") as f:
        return json.load(f)

def write_users(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=4)

def client_handler(conn, addr):
    print(f"[CONNECTED] {addr} joined the server.")
    conn.send(b"Welcome!\nType REGISTER or LOGIN to continue:\n")
    users = read_users()

    try:
        mode = conn.recv(1024).decode().strip().upper()

        if mode == "REGISTER":
            conn.send(b"Enter new username: ")
            username = conn.recv(1024).decode().strip()
            conn.send(b"Enter new password: ")
            password = conn.recv(1024).decode().strip()

            if username in users:
                conn.send(b"Username already taken.\n")
            else:
                users[username] = password
                write_users(users)
                conn.send(b"Registration complete.\n")

        elif mode == "LOGIN":
            conn.send(b"Username: ")
            username = conn.recv(1024).decode().strip()
            conn.send(b"Password: ")
            password = conn.recv(1024).decode().strip()

            if username in users and users[username] == password:
                conn.send(b"Login successful!\n")
            else:
                conn.send(b"Invalid credentials.\n")
        else:
            conn.send(b"Invalid command. Try again.\n")

    except Exception as e:
        print(f"[ERROR] {addr}: {e}")
    finally:
        conn.close()
        print(f"[DISCONNECTED] {addr}")

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[RUNNING] Server listening at {HOST}:{PORT}")

    while True:
        conn, addr = server.accept()
        threading.Thread(target=client_handler, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_server()
