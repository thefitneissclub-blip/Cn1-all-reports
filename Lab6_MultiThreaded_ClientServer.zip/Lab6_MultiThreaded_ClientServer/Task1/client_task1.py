import socket

HOST = "127.0.0.1"
PORT = 5050

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

try:
    while True:
        data = client.recv(1024).decode()
        print(data, end="")
        msg = input()
        client.send(msg.encode())
        if msg.lower() == "quit":
            break
except KeyboardInterrupt:
    pass
finally:
    client.close()
