import socket, os

HOST='127.0.0.1'; PORT=2121
s=socket.socket(); s.connect((HOST,PORT))

print(s.recv(1024).decode()); s.send(input("Username: ").encode())
print(s.recv(1024).decode()); s.send(input("Password: ").encode())
print(s.recv(1024).decode())

while True:
    cmd=input("ftp> "); s.send(cmd.encode())
    if cmd=="QUIT": print(s.recv(1024).decode()); break
    print(s.recv(1024).decode())
s.close()
