import socket, os

USERS={"student1":"1234","student2":"abcd"}
HOST='127.0.0.1'; PORT=2121
ROOT=os.path.join(os.getcwd(),"ftproot")
if not os.path.exists(ROOT): os.makedirs(ROOT)

s=socket.socket(); s.bind((HOST,PORT)); s.listen(5)

while True:
    c,a=s.accept()
    c.send(b"220 Welcome\nUsername: "); u=c.recv(1024).decode().strip()
    c.send(b"Password: "); p=c.recv(1024).decode().strip()

    if u in USERS and USERS[u]==p:
        c.send(b"230 Login OK! Commands: LIST, DELETE <file>, QUIT")
    else:
        c.send(b"530 Login failed"); c.close(); continue

    while True:
        cmd=c.recv(1024).decode()
        if cmd=="QUIT": c.send(b"221 Bye"); break
        elif cmd=="LIST": c.send("\n".join(os.listdir(ROOT)).encode())
        elif cmd.startswith("DELETE"):
            f=cmd.split()[1]; path=os.path.join(ROOT,f)
            if os.path.exists(path): os.remove(path); c.send(b"File deleted")
            else: c.send(b"File not found")
        else: c.send(b"Unknown command")
    c.close()
