import socket

HOST='127.0.0.1'; PORT=2121
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.connect((HOST,PORT))

print(s.recv(1024).decode()); s.send(input("Username: ").encode())
print(s.recv(1024).decode()); s.send(input("Password: ").encode())

print(s.recv(1024).decode())

while True:
    cmd=input("ftp> "); s.send(cmd.encode())
    if cmd=="QUIT": print(s.recv(1024).decode()); break
    print(s.recv(4096).decode())
s.close()
