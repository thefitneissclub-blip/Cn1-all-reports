import socket
import os

USERS = {"student1": "1234", "student2": "abcd"}

HOST='127.0.0.1'; PORT=2121
ROOT=os.path.join(os.getcwd(),"ftproot")
if not os.path.exists(ROOT): os.makedirs(ROOT)

server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server_socket.bind((HOST,PORT)); server_socket.listen(5)

while True:
    conn,addr=server_socket.accept()
    conn.send(b"220 Welcome to FTP Server\nUsername: ")
    username=conn.recv(1024).decode().strip()
    conn.send(b"Password: ")
    password=conn.recv(1024).decode().strip()

    if username in USERS and USERS[username]==password:
        conn.send(b"230 Login successful! Commands: LIST, QUIT")
    else:
        conn.send(b"530 Login failed."); conn.close(); continue

    while True:
        command=conn.recv(1024).decode()
        if command=="QUIT":
            conn.send(b"221 Goodbye!"); break
        elif command=="LIST":
            files=os.listdir(ROOT); conn.send("\n".join(files).encode())
        else:
            conn.send(b"Unknown command")
    conn.close()
