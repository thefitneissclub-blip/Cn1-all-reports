import socket

def start_client():
    host = input("Enter server IP Address: ").strip()
    port = int(input("Enter server Port: ").strip())
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    message = input("Message (e.g. 'Client 1'): ").strip()
    client_socket.send(message.encode())
    response = client_socket.recv(1024).decode()
    print(f"[Server]: {response}")
    client_socket.close()

if __name__ == "__main__":
    start_client()
