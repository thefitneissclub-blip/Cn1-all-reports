import socket

def start_client():
    host = input("Enter server IP Address: ").strip()
    port = int(input("Enter server Port: ").strip())
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    print("[Server]:", client_socket.recv(1024).decode())
    while True:
        message = input("[Client] ")
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()
        print("[Server]:", response)
        if message.lower() == "disconnect":
            break
    client_socket.close()

if __name__ == "__main__":
    start_client()
