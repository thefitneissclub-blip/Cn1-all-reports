import socket

def start_client():
    host = input("Enter server IP: ")
    port = int(input("Enter port: "))
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))

    while True:
        msg = s.recv(1024).decode()
        print("[Server]", msg.strip())
        if "Connection Established" in msg or "terminated" in msg: break
        ans = input("[Client] ")
        s.send(ans.encode())

    while True:
        msg = input("[Client] ")
        s.send(msg.encode())
        resp = s.recv(1024).decode()
        print("[Server]", resp.strip())
        if msg.lower() == "disconnect": break

    s.close()

if __name__ == "__main__":
    start_client()
