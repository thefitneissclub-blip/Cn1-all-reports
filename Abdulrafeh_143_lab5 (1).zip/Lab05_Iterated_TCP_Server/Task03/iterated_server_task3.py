import socket, os

USERS_FILE = "users.txt"

def load_users():
    users = {}
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE) as f:
            for line in f:
                if ":" in line:
                    u, p = line.strip().split(":")
                    users[u] = p
    return users

def save_user(username, password):
    with open(USERS_FILE, "a") as f:
        f.write(f"{username}:{password}\n")

def start_server():
    host, port = "127.0.0.1", 9000
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    s.listen(3)
    print(f"[*] Server listening on {host}:{port}")

    while True:
        conn, addr = s.accept()
        print(f"[+] Connected by {addr}")
        users = load_users()
        conn.send("Welcome! (1) Signup or (2) Login? ".encode())
        choice = conn.recv(1024).decode().strip().lower()

        if choice in ["1", "signup"]:
            conn.send("Username: ".encode())
            u = conn.recv(1024).decode().strip()
            if u in users:
                conn.send("User exists. Reconnect.\n".encode()); conn.close(); continue
            conn.send("Password: ".encode()); p = conn.recv(1024).decode().strip()
            conn.send("Retype password: ".encode()); p2 = conn.recv(1024).decode().strip()
            if p != p2: conn.send("Passwords mismatch. Reconnect.\n".encode()); conn.close(); continue
            save_user(u, p); conn.send(f"User '{u}' registered!\n".encode())

        elif choice in ["2", "login"]:
            ok = False
            while not ok:
                conn.send("Username: ".encode()); u = conn.recv(1024).decode().strip()
                conn.send("Password: ".encode()); p = conn.recv(1024).decode().strip()
                users = load_users()
                if u in users and users[u] == p:
                    conn.send(f"Welcome {u}!\n".encode()); ok = True
                else:
                    conn.send("Invalid credentials. Try again.\n".encode())
        else:
            conn.send("Invalid choice. Disconnecting.\n".encode()); conn.close(); continue

        conn.send("Connection Established. Type 'disconnect' to quit.\n".encode())
        while True:
            data = conn.recv(1024).decode().strip()
            if not data: break
            print(f"[Client {addr}]: {data}")
            if data.lower() == "disconnect":
                conn.send("Connection terminated.\n".encode()); conn.close(); break
            else:
                conn.send(f"{data} (Echoed)".encode())

if __name__ == "__main__":
    start_server()
