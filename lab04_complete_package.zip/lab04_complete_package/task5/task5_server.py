import socket

host = 'localhost'
port = 8000
data_payload = 2048

users = ["ali","ahmed","fatima","usman","aliyan"]

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((host, port))
sock.listen()

print("Server running...")
client, address = sock.accept()

data = client.recv(data_payload).decode()
print("Received:", data)

reply = "Unknown user"
for u in users:
    if u.lower() in data.lower():
        reply = f"Hello {u}!"
        break

client.send(reply.encode())
client.close()
sock.close()
