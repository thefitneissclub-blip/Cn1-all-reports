import socket

host = 'localhost'
port = 8000

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((host, port))

message = input("Enter your message (include your name): ")
sock.sendall(message.encode())

data = sock.recv(1024).decode()
print("Server says:", data)

sock.close()
