import socket

host = 'localhost'
port = 8000
data_payload = 2048

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

sock.bind((host, port))
sock.listen()

print(f"Server machine IP: {socket.gethostbyname(socket.gethostname())}")
print(f"Server running on port {port}")
print("Waiting for a client...")

client, address = sock.accept()
print(f"Client connected: {address}")

data = client.recv(data_payload)
print(f"Received from client: {data.decode()}")

client.send(data)
client.close()
sock.close()
