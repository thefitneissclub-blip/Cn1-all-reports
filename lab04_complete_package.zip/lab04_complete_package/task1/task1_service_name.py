import socket

ports = [20,21,22,23,25,53,67,80,110,143]

for p in ports:
    try:
        print(f"Port {p} => Service Name: {socket.getservbyport(p, 'tcp')}")
    except:
        print(f"Port {p} => No TCP service found")
