import socket

domains = [
    "www.google.com","www.youtube.com","www.facebook.com","www.instagram.com",
    "www.twitter.com","www.github.com","www.python.org","www.microsoft.com",
    "www.apple.com","www.reddit.com"
]

for d in domains:
    try:
        print(f"{d} --> {socket.gethostbyname(d)}")
    except:
        print(f"Could not resolve domain: {d}")
