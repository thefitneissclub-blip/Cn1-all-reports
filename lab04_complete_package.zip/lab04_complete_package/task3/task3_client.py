import socket

host = 'localhost'
port = int(input("Enter server port: "))

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((host, port))

message = input("Enter a message to send to the server: ")
sock.sendall(message.encode())

data = sock.recv(256)
print(f"Received from server: {data.decode()}")

sock.close()
