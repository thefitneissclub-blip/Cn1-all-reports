import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_addr = ('localhost', 7777)

nums = input("Enter two numbers (e.g. 10 20): ")
client_socket.sendto(nums.encode(), server_addr)

data, _ = client_socket.recvfrom(1024)
print("Sum:", data.decode())

client_socket.close()