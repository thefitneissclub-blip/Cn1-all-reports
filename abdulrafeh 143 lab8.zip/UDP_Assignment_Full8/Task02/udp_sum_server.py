import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 7777))
print("UDP Sum Server is running...")

while True:
    data, address = server_socket.recvfrom(1024)
    numbers = data.decode()
    print(f"Received: {numbers}")
    num1, num2 = numbers.split()
    result = int(num1) + int(num2)
    server_socket.sendto(str(result).encode(), address)