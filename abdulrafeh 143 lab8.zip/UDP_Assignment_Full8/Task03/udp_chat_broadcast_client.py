import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.bind(('localhost', 0))
server_addr = ('localhost', 6000)

def receive_messages():
    while True:
        try:
            data, _ = client.recvfrom(1024)
            print("\n" + data.decode())
        except:
            break

thread = threading.Thread(target=receive_messages, daemon=True)
thread.start()

print("Connected! Type exit to leave")

while True:
    msg = input("> ")
    client.sendto(msg.encode(), server_addr)
    
    if msg.lower() == "exit":
        break

client.close()