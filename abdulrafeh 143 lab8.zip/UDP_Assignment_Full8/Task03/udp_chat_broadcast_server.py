import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 6000))
print("UDP Broadcast Chat Server Running...")
clients = set()

while True:
    data, addr = server_socket.recvfrom(1024)
    message = data.decode()
    clients.add(addr)

    if message.lower() == "exit":
        print(f"Client left: {addr}")
        clients.remove(addr)
        continue

    print(f"{addr}: {message}")
    for client in clients:
        if client != addr:
            server_socket.sendto(f"{addr}: {message}".encode(), client)