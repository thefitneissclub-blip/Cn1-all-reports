import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = ('localhost', 9999)
message = input("Enter message for server: ")
client_socket.sendto(message.encode(), server_address)
response, _ = client_socket.recvfrom(1024)
print("Server Time:", response.decode())
client_socket.close()