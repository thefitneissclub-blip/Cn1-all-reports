import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 8888))
print("Chat Server is ready...")

while True:
    data, address = server_socket.recvfrom(1024)
    message = data.decode()

    if message.lower() == "exit":
        print(f"Client {address} exited chat!")
        continue
    
    print(f"Client {address}: {message}")
    server_socket.sendto("Message received".encode(), address)