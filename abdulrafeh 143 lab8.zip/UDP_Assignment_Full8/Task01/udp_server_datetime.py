import socket
from datetime import datetime

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 9999))
print("UDP Server (Date-Time) is running...")

while True:
    data, address = server_socket.recvfrom(1024)
    print(f"Client says: {data.decode()} from {address}")
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    server_socket.sendto(current_time.encode(), address)