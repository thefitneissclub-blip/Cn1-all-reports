import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = ('localhost', 8888)
print("Type 'exit' to leave chat")

while True:
    msg = input("You: ")
    client_socket.sendto(msg.encode(), server_address)

    if msg.lower() == "exit":
        print("Exiting chat...")
        break

    data, _ = client_socket.recvfrom(1024)
    print("Server:", data.decode())

client_socket.close()