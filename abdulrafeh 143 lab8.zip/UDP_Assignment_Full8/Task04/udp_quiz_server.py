import socket

quiz = {
    "What is the capital of Pakistan? ": "Islamabad",
    "2 + 2 = ? ": "4",
    "Which language are we using? ": "Python",
    "What protocol is used (TCP/UDP)? ": "UDP"
}

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(('localhost', 7000))
print("Quiz Server Ready!")

while True:
    data, addr = server.recvfrom(1024)
    if data.decode().lower() == "start":
        score = 0
        for q, ans in quiz.items():
            server.sendto(q.encode(), addr)
            data, _ = server.recvfrom(1024)
            if data.decode().strip().lower() == ans.lower():
                score += 1
                server.sendto("Correct ✅".encode(), addr)
            else:
                server.sendto("Wrong ❌".encode(), addr)
        server.sendto(f"Quiz Over! Score: {score}/{len(quiz)}".encode(), addr)