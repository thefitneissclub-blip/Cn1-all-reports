import socket

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server = ('localhost', 7000)

input("Press ENTER to start quiz...")
client.sendto("start".encode(), server)

while True:
    data, _ = client.recvfrom(1024)
    msg = data.decode()
    if "Score" in msg:
        print(msg)
        break
    print("Question:", msg)
    ans = input("Answer: ")
    client.sendto(ans.encode(), server)

client.close()