#!/usr/bin/env python3
"""Time Synchronization Server (Berkeley-like)
Usage: python server.py --host 0.0.0.0 --port 9999 --interval 15
"""
import threading
import socket
import time
import argparse
import json
import statistics

LOCK = threading.Lock()

class ClientHandler:
    def __init__(self, conn, addr, client_id):
        self.conn = conn
        self.addr = addr
        self.id = client_id
        self.alive = True
        self.lock = threading.Lock()

    def fileno(self):
        return self.conn.fileno()

    def send(self, msg):
        try:
            with self.lock:
                self.conn.sendall(msg.encode('utf-8'))
        except Exception as e:
            print(f"[Server] send error to {self.id}: {e}")
            self.alive = False

    def recv_line(self, timeout=5.0):
        try:
            self.conn.settimeout(timeout)
            data = b''
            while not data.endswith(b'\n'):
                chunk = self.conn.recv(4096)
                if not chunk:
                    raise ConnectionError('socket closed')
                data += chunk
            return data.decode('utf-8').strip()
        except Exception:
            # mark dead on error/timeout
            self.alive = False
            return None

    def close(self):
        try:
            self.conn.close()
        except:
            pass
        self.alive = False

class TimeServer:
    def __init__(self, host, port, sync_interval=10):
        self.host = host
        self.port = port
        self.sync_interval = sync_interval
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.clients = {}
        self.next_id = 1
        self.running = True

    def start(self):
        self.sock.bind((self.host, self.port))
        self.sock.listen(50)
        print(f"[Server] Listening on {self.host}:{self.port}")
        threading.Thread(target=self._accept_loop, daemon=True).start()
        self._command_loop()

    def _accept_loop(self):
        while self.running:
            try:
                conn, addr = self.sock.accept()
            except Exception:
                continue
            with LOCK:
                cid = f"C{self.next_id}"
                self.next_id += 1
                handler = ClientHandler(conn, addr, cid)
                self.clients[cid] = handler
            print(f"[Server] New client {cid} from {addr}")
            threading.Thread(target=self._client_reader, args=(handler,), daemon=True).start()

    def _client_reader(self, handler: ClientHandler):
        # Expect initial HELLO line (client id or metadata)
        line = handler.recv_line(timeout=3.0)
        if line is None:
            print(f"[Server] Client {handler.id} disconnected during hello")
            with LOCK:
                self.clients.pop(handler.id, None)
            handler.close()
            return
        print(f"[Server] {handler.id} says: {line}")

    def _gather_times(self, timeout_per_client=5.0):
        results = {}
        rtts = []
        send_times = {}
        # Step 1: send POLL and record send time
        for cid, h in list(self.clients.items()):
            if not h.alive:
                continue
            try:
                send_times[cid] = time.time()
                h.send('POLL\n')
            except Exception as e:
                print(f"[Server] send poll error to {cid}: {e}")
                h.alive = False
        # Step 2: receive replies
        for cid, h in list(self.clients.items()):
            if not h.alive or cid not in send_times:
                continue
            line = h.recv_line(timeout=timeout_per_client)
            recv_time = time.time()
            if not line:
                print(f"[Server] No reply from {cid}")
                continue
            try:
                payload = json.loads(line)
                client_time = float(payload['local_time'])
            except Exception as e:
                print(f"[Server] Bad reply from {cid}: {line}; {e}")
                continue
            rtt = recv_time - send_times[cid]
            est_client_time = client_time + rtt / 2.0
            results[cid] = {
                'client_time': client_time,
                'recv_time_server': recv_time,
                'send_time_server': send_times[cid],
                'rtt': rtt,
                'est_client_time': est_client_time
            }
            rtts.append(rtt)
        return results, rtts

    def _compute_consensus(self, results):
        # Include server's local time at the point of computation
        now = time.time()
        est_list = [now]
        for cid, info in results.items():
            est_list.append(info['est_client_time'])
        # Robust: exclude outliers using median absolute deviation (MAD)
        med = statistics.median(est_list)
        deviations = [abs(x - med) for x in est_list]
        mad = statistics.median(deviations) if deviations else 0
        # Keep those within 2*MAD + small epsilon, otherwise exclude
        if mad == 0:
            filtered = est_list
        else:
            threshold = 2 * mad + 0.001
            filtered = [x for x in est_list if abs(x - med) <= threshold]
        # Final consensus: trimmed mean of filtered values
        if not filtered:
            consensus = med
        else:
            consensus = sum(filtered) / len(filtered)
        return consensus, now

    def _send_adjusts(self, consensus, results):
        # Send ADJUST messages of the form: ADJUST {offset}\n
        for cid, info in results.items():
            est = info['est_client_time']
            offset = consensus - est
            h = self.clients.get(cid)
            if not h or not h.alive:
                continue
            msg = json.dumps({'cmd': 'ADJUST', 'offset': offset}) + '\n'
            h.send(msg)

    def sync_once(self):
        with LOCK:
            client_count = len(self.clients)
        print(f"[Server] Starting sync round with {client_count} clients")
        results, rtts = self._gather_times()
        if not results:
            print("[Server] No client results collected (skip)")
            return
        median_rtt = statistics.median(rtts) if rtts else 0
        consensus, server_now = self._compute_consensus(results)
        print(f"[Server] median RTT={median_rtt:.4f}s, server_time={server_now:.6f}, consensus_time={consensus:.6f}")
        # send adjustments
        self._send_adjusts(consensus, results)
        # logging per-client
        for cid, info in results.items():
            print(f"[Server] {cid}: rtt={info['rtt']:.4f}s est_client_time={info['est_client_time']:.6f}")

    def _command_loop(self):
        print("[Server] Press Enter to trigger sync; type 'exit' to quit")
        while True:
            try:
                cmd = input().strip()
            except EOFError:
                cmd = 'exit'
            if cmd == 'exit':
                print("[Server] Shutting down")
                self.running = False
                try:
                    self.sock.close()
                except:
                    pass
                with LOCK:
                    for h in self.clients.values():
                        h.close()
                    self.clients.clear()
                break
            # trigger sync
            try:
                self.sync_once()
            except Exception as e:
                print(f"[Server] sync error: {e}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=9999)
    parser.add_argument('--interval', type=int, default=15)
    args = parser.parse_args()
    server = TimeServer(args.host, args.port, sync_interval=args.interval)
    server.start()
