#!/usr/bin/env python3
"""Time Synchronization Client
Simulates a local clock with drift and network jitter.
Usage: python client.py --host 127.0.0.1 --port 9999 --drift_ppm 100 --min_delay 0.05 --max_delay 0.5
"""
import socket
import argparse
import time
import threading
import json
import random

class SimClock:
    def __init__(self, drift_ppm=0.0):
        # drift_ppm: parts per million (seconds per million real seconds)
        self.drift_ppm = drift_ppm
        self.drift = drift_ppm / 1_000_000.0
        self.start_real = time.time()
        self.start_clock = self.start_real
        self.offset = 0.0

    def now(self):
        # simulated local time = real time + extra drift since start + offset
        real_now = time.time()
        elapsed = real_now - self.start_real
        # clock runs at (1 + drift) speed relative to real time
        clock = self.start_clock + elapsed * (1.0 + self.drift) + self.offset
        return clock

    def apply_offset(self, delta):
        self.offset += delta

class Client:
    def __init__(self, host, port, drift_ppm=0.0, min_delay=0.01, max_delay=0.2, name=None):
        self.host = host
        self.port = port
        self.name = name or 'client'
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clock = SimClock(drift_ppm)
        self.min_delay = float(min_delay)
        self.max_delay = float(max_delay)
        self.running = True
        self.lock = threading.Lock()

    def connect(self):
        try:
            self.sock.connect((self.host, self.port))
        except Exception as e:
            print(f"[Client:{self.name}] connect error: {e}")
            return
        hello = json.dumps({'client': self.name, 'drift_ppm': self.clock.drift_ppm}) + '\n'
        try:
            self.sock.sendall(hello.encode('utf-8'))
        except Exception as e:
            print(f"[Client:{self.name}] hello send error: {e}")
            self.sock.close()
            return
        threading.Thread(target=self._listen_loop, daemon=True).start()
        print(f"[Client:{self.name}] Connected to server {self.host}:{self.port}")

    def _listen_loop(self):
        buffer = b''
        while self.running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    raise ConnectionError('server closed')
                buffer += data
                while b'\n' in buffer:
                    line, buffer = buffer.split(b'\n', 1)
                    line = line.decode('utf-8').strip()
                    self._handle_line(line)
            except Exception as e:
                print(f"[Client:{self.name}] connection error: {e}")
                self.running = False
                try:
                    self.sock.close()
                except:
                    pass
                break

    def _handle_line(self, line):
        if line == 'POLL':
            local_time = self.clock.now()
            simulated_send_delay = random.uniform(self.min_delay, self.max_delay)
            time.sleep(simulated_send_delay)
            payload = json.dumps({'local_time': local_time}) + '\n'
            try:
                with self.lock:
                    self.sock.sendall(payload.encode('utf-8'))
            except Exception as e:
                print(f"[Client:{self.name}] send error: {e}")
                self.running = False
        else:
            try:
                obj = json.loads(line)
                if obj.get('cmd') == 'ADJUST':
                    offset = float(obj['offset'])
                    print(f"[Client:{self.name}] Received ADJUST offset={offset:.6f}s")
                    # apply offset immediately (could be slewed in real systems)
                    self.clock.apply_offset(offset)
                    print(f"[Client:{self.name}] New local_time={self.clock.now():.6f}")
            except Exception:
                print(f"[Client:{self.name}] Unknown message: {line}")

    def close(self):
        self.running = False
        try:
            self.sock.close()
        except:
            pass

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=9999)
    parser.add_argument('--drift_ppm', type=float, default=0.0,
                        help='clock drift in parts-per-million (ppm)')
    parser.add_argument('--min_delay', type=float, default=0.05, help='min simulated one-way delay')
    parser.add_argument('--max_delay', type=float, default=0.3, help='max simulated one-way delay')
    parser.add_argument('--name', default=None)
    args = parser.parse_args()

    c = Client(args.host, args.port, drift_ppm=args.drift_ppm, min_delay=args.min_delay, max_delay=args.max_delay, name=args.name)
    c.connect()
    try:
        while c.running:
            time.sleep(1)
    except KeyboardInterrupt:
        c.close()
