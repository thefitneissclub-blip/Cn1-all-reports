#!/usr/bin/env python3
import socket, time, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--host',default='127.0.0.1')
ap.add_argument('--port',type=int,default=10000)
ap.add_argument('--interval',type=float,default=1)
a=ap.parse_args()
while True:
    try:
        s=socket.socket(); s.connect((a.host,a.port))
        print("[Client] resp:",s.recv(64))
        s.close()
    except Exception as e:
        print("err",e)
    time.sleep(a.interval)
