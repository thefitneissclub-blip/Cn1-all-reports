#!/usr/bin/env python3
import socket, time, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--host',default='127.0.0.1')
ap.add_argument('--port',type=int,default=10000)
ap.add_argument('--rate',type=float,default=0.02)
ap.add_argument('--num',type=int,default=50)
a=ap.parse_args()
while True:
    for i in range(a.num):
        try:
            s=socket.socket(); s.connect((a.host,a.port))
            s.close()
        except: pass
    time.sleep(a.rate)
