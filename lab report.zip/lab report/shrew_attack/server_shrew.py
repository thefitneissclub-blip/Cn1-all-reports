#!/usr/bin/env python3
import socket, threading, time, argparse, statistics
WINDOW=3; BLACKLIST=10
class Server:
    def __init__(self,h,p):
        self.h=h; self.p=p; self.rates=[]; self.bl={}
    def run(self):
        s=socket.socket(); s.bind((self.h,self.p)); s.listen()
        print("[Server] Listening",self.h,self.p)
        while True:
            c,a=s.accept()
            ip=a[0]
            now=time.time()
            self.bl={ip:t for ip,t in self.bl.items() if t>now}
            if ip in self.bl:
                c.close(); continue
            threading.Thread(target=self.handle,args=(c,ip)).start()
    def handle(self,c,ip):
        now=time.time(); self.rates.append(now)
        self.rates=self.rates[-50:]
        if len(self.rates)>3:
            isi=[self.rates[i]-self.rates[i-1] for i in range(1,len(self.rates))]
            if statistics.pvariance(isi)<0.001:
                print("[DETECT] Shrew attack from",ip)
                self.bl[ip]=time.time()+BLACKLIST
        try:
            c.sendall(b"PONG")
        finally: c.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--host',default='0.0.0.0')
    ap.add_argument('--port',type=int,default=10000)
    a=ap.parse_args()
    Server(a.host,a.port).run()
